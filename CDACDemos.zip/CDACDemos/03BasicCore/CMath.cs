﻿namespace _Math
{
    internal class CMath
    {
        public void Add(int x,int y)
        {
            Console.WriteLine(x+y);
        }
    }
}
