﻿//Console.WriteLine("Hello, World!");
using _Math;

CMath cmathObj =new CMath();
cmathObj.Add(10, 20);
Myclass myclass = new Myclass();
myclass.Greet();
Console.ReadLine();

public class Myclass
{
    public void Greet()
    {
        Console.WriteLine("Hello there !!");
    }

}
