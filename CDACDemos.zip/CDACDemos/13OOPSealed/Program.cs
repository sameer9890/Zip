﻿namespace _13OOPSealed
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String 
        }
    }
    public sealed class MyButton
    {
        public void RoundButton(string VideoURL)//$ 1000 
        {
            //code here...
        }
    }
    //public class CDAC :MyButton
    //{
    //    public void MyCustomiseButton()
    //    {
    //        base.RoundButton();
    //    }
    //}
}
