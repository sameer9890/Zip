﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Entity_framework.Model;
using Microsoft.Extensions.Options;
//using Entity_framework_Db.DAL;
//using DbContext = Entity_framework_Db.DAL.DbContext;

namespace Entity_framework.DAL
{
    internal class CdacDbContext : DbContext
    {
        public DbSet<Customer> customers { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
 
        
        {
            var builder = new ConfigurationBuilder();
            builder.SetBasePath(Directory.GetCurrentDirectory());
            builder.AddJsonFile("appsettings.json");
            IConfiguration configuration = builder.Build();
            var conStr = configuration.GetSection("ConnectionStrings");
            var str = conStr.GetValue<string>("con");
            optionsBuilder.UseSqlServer(str);
        }
    }
}
