﻿using _01MVC.DAL;
using _01MVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;


namespace _01MVC.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}
        EmpDbContext db=new EmpDbContext();

       

        public IActionResult Index()
        {
            List<Emp> lstEmps = db.SelectEmpRecord();

            return View(lstEmps);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();

        }

        public IActionResult AfterCreate(Emp emp)
        {
            int rowsAffted = db.InsertEmpRecord(emp);
            if (rowsAffted > 0)
            {
                return Redirect("/Home/Index");//instructions to browser - to generate GET call
            }
            else
            {
                return View("Create");
            }


        }

        public IActionResult Edit(int id)
        {
            List<Emp> emps = db.SelectEmpRecord().ToList();

            var emp = (from e in emps
                       where e.Id == id
                       select e).First();

            return View(emp);
        }

        public IActionResult AfterEdit(Emp emp)
        {
            List<Emp> emps = db.SelectEmpRecord().ToList();

            var empToBeUpdted = (from e in emps
                                 where e.Id == emp.Id
                                 select e).First();
            db.UpdateEmpRecord(emp);
            return Redirect("/Home/Index");
        }

        public IActionResult Delete(int id)
        {
            db.DeleteEmpRecord(id);
            return Redirect("/Home/Index");
        }

    }
}
