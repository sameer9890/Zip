﻿namespace _01MVC.Models;

public class Emp
{
    public int Id { get; set; }
    public string ?Name { get; set; }
    public string ?Address { get; set; }
}
