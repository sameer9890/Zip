﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace _02MVC_MyController.Models
{
    [Table("Emp")]
    public class Emp
    {
        [Column("Id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("Name", TypeName = "varchar")]
        [StringLength(50)]
        public string? Name { get; set; }

        [Column("Address", TypeName = "varchar")]
        [StringLength(50)]
        public string? Address { get; set; }
    }
}
