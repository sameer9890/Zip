﻿using _02MVC_MyController.DAL;
using _02MVC_MyController.Models;
using Microsoft.AspNetCore.Mvc;

namespace _02MVC_MyController.Controllers
{
    public class DacController : Controller
    {
        private EmpDbContext _empDbContext;

        public DacController(EmpDbContext empDbContext)
        {
            _empDbContext= empDbContext;
        }
        public IActionResult Index()
        {
            List<Emp> lstEmp= _empDbContext.emps.ToList();
            return View(lstEmp);
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult AfterCreate(Emp emp)
        {
 
            _empDbContext.emps.Add(emp);
            int rowsAffected = _empDbContext.SaveChanges();
            if (rowsAffected > 0)
            {
                return Redirect("/Dac/Index");//instructions to browser - to generate GET call
            }
            else
            {
                return View("Create");
            }
            

        }
        public IActionResult Edit(int id)
        {
            List<Emp> emps = _empDbContext.emps.ToList();

            var emp = (from e in emps
                       where e.Id == id
                       select e).First();

            //_empDbContext.emps.Add(emp);
            return View(emp);
        }

        public IActionResult AfterEdit(Emp emp)
        {
            List<Emp> emps = _empDbContext.emps.ToList();

            var empToBeUpdted = (from e in emps
                                 where e.Id == emp.Id
                                 select e).First();
            //emps = empToBeUpdted;
            int rowsAffected =_empDbContext.SaveChanges();
            return Redirect("/Dac/Index");

           // Customer custToBeUpdated = db.customers.Find(no);
        }


        public IActionResult Delete(int id)
        {
            return Redirect("/Dac/Index");
        }

       

    }
}
