﻿using _02MVC_MyController.Models;
using Microsoft.EntityFrameworkCore;

namespace _02MVC_MyController.DAL
{
    public class EmpDbContext : DbContext
    {
        public DbSet<Emp> emps { get; set; }


        public EmpDbContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        public DbSet<Emp> Emps { get; set; }
    }
}
